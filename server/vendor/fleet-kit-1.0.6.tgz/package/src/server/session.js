// The session: an httpOnly __Host-<app>_session cookie the server sets, holding an HS256 token
// (jwt.js) with who it is and `tv`, the account's token_version when it was minted. Never a token
// in localStorage, which any script that gets onto the page can read.
//
// With `load`, every request reads the account's own row: a session whose tv is behind the row's
// (signed out since, on any device) is refused, and so is one whose row is gone (a swept guest).
// Without `load` (an app that keeps no accounts table) the token itself says who it is.
//
// Sessions slide: /me, which every page load asks, renews one older than a day, so only
// `ttlMs` without a visit ends it. `onRenew` runs then (stamp last_seen_at; the waypoint module
// also tells Waypoint a guest is still in use, or Waypoint forgets it after a month).
//
// Moving an app onto this session without signing anyone out: `legacy` readers take the old
// cookie (or, once, the old bearer token) and say who it is; the kit sets its own cookie in its
// place and clears the old one. A reader that also gives `exp` (seconds) keeps that end: the
// swap never makes a session last longer than it would have.
//
// Who is the site admin: ADMIN_CENTRAL_USER_IDS by default (admin.js). An app with admins of its
// own passes `isAdmin(user, { listed })`, sync or async, answering true for an admin (`listed` is
// the default answer, to keep the list and add to it). A guest is never an admin, whatever the
// hook says; a hook that throws, or answers anything but true, means no.
import { signJwt, verifyJwt } from './jwt.js';
import { cookieOpts, hostCookie, readCookie } from './cookies.js';
import { isAdmin } from './admin.js';

const DAY_MS = 24 * 60 * 60 * 1000;
const RESERVED = new Set(['sub', 'cid', 'name', 'guest', 'tv', 'iat', 'exp', 'nbf']);

const bearerOf = (req) => {
  const h = req.headers?.authorization;
  return typeof h === 'string' && h.startsWith('Bearer ') ? h.slice(7).trim() : null;
};

/** The token's claims for an account (the app's row, or what onSignIn returned): sub (the row's
 *  id, else the central id), cid, name, guest, tv, plus whatever `extra(user)` adds. */
export function claimsOf(user, extra) {
  const more = extra ? extra(user) || {} : {};
  for (const k of Object.keys(more)) if (RESERVED.has(k)) throw new Error(`session claim "${k}" is the kit's own`);
  return {
    ...more,
    sub: String(user.id ?? user.central_user_id),
    cid: user.central_user_id ?? null,
    name: user.username ?? user.name ?? null,
    guest: Boolean(user.is_guest),
    tv: Number(user.token_version ?? 0),
  };
}

/** The account a token names, when the app has no row to read. */
export function userFromClaims(claims) {
  const extra = Object.fromEntries(Object.entries(claims).filter(([k]) => !RESERVED.has(k)));
  return { ...extra, id: claims.sub, central_user_id: claims.cid ?? null, username: claims.name ?? null, is_guest: Boolean(claims.guest), token_version: Number(claims.tv ?? 0) };
}

export function createSession({
  app,
  secret,
  env = process.env,
  ttlMs = 30 * DAY_MS,
  slide = true,
  renewAfterMs = DAY_MS,
  load,
  claims: extraClaims,
  legacy = [],
  onRenew,
  onSignOut,
  isAdmin: adminHook,
  now = Date.now,
} = {}) {
  if (typeof app !== 'string' || !/^[a-z][a-z0-9-]{0,23}$/i.test(app)) throw new Error('createSession needs a short app code, like "sf"');
  if (adminHook !== undefined && typeof adminHook !== 'function') throw new Error('isAdmin must be a function (user, { listed }) => true for an admin');
  const name = hostCookie(app, 'session');

  /** Whether an account is the site admin: the hook's word when there is one (awaited), else the
   *  list. Never a guest; a failing hook is a no. */
  async function adminOf(user) {
    if (!user || user.is_guest) return false;
    const listed = isAdmin(user, env);
    if (!adminHook) return listed;
    try {
      return (await adminHook(user, { listed })) === true;
    } catch (err) {
      console.error('Admin check failed:', err?.message ?? err);
      return false;
    }
  }
  /** The same without waiting (a socket upgrade): an async hook's answer is not there yet, so it
   *  counts as no. */
  function adminOfNow(user) {
    if (!user || user.is_guest) return false;
    const listed = isAdmin(user, env);
    if (!adminHook) return listed;
    try {
      const answer = adminHook(user, { listed });
      if (answer && typeof answer.then === 'function') {
        answer.then(null, () => {});
        return false;
      }
      return answer === true;
    } catch {
      return false;
    }
  }
  // read when used, so a server that starts without it says so per request instead of crashing
  const key = () => secret || env.SESSION_SECRET || env.JWT_SECRET || '';
  const ttlFor = (user) => (typeof ttlMs === 'function' ? ttlMs(user) : ttlMs);
  const clearLegacy = (res, l) => {
    if (l?.cookie && l.cookie !== name) res.clearCookie(l.cookie, l.clearOpts ?? cookieOpts());
  };

  function mint(user, { ttl } = {}) {
    return signJwt(claimsOf(user, extraClaims), key(), { ttlMs: ttl ?? ttlFor(user), now: now() });
  }
  function set(res, user, { ttl = ttlFor(user) } = {}) {
    res.cookie(name, mint(user, { ttl }), cookieOpts({ maxAge: ttl }));
  }
  function clear(res) {
    res.clearCookie(name, cookieOpts());
    for (const l of legacy) clearLegacy(res, l);
  }

  /** The session a request carries, if its signature and date hold: { claims, legacy }, or null.
   *  Synchronous and reads no database (a WebSocket upgrade can use it); whether it was signed
   *  out since is the row's to say (resolve). */
  function read(req) {
    const k = key();
    if (!k) return null;
    const raw = readCookie(req, name);
    const mine = raw ? verifyJwt(raw, k, { now: now() }) : null;
    if (mine && mine.sub !== undefined) return { claims: mine, legacy: null };
    for (const l of legacy) {
      const value = l.cookie ? readCookie(req, l.cookie) : l.bearer ? bearerOf(req) : null;
      if (!value) continue;
      let got = null;
      try {
        got = l.read(value, req);
      } catch {
        got = null;
      }
      if (got && got.sub !== undefined && got.sub !== null) return { claims: got, legacy: l };
    }
    return null;
  }

  /** Who is asking, once per request: { user } (null when signed out), with `failed` when the
   *  row could not be read (answer 500: a database restart must not sign the table out). Sets
   *  req.user. A legacy session is swapped for the kit's own cookie on the way. */
  async function resolve(req, res) {
    if (req.fleetSession) return req.fleetSession;
    const done = (r) => {
      req.fleetSession = r;
      req.user = r.user ?? null;
      return r;
    };
    const found = read(req);
    if (!found) return done({ user: null, claims: null });
    let user;
    if (load) {
      try {
        user = await load(found.claims, req);
      } catch (err) {
        console.error('Session check failed:', err?.message ?? err);
        return done({ user: null, claims: found.claims, failed: true });
      }
      // a session from before token_version carries no number: it is version 0, like its row
      if (user && Number(found.claims.tv ?? 0) !== Number(user.token_version ?? 0)) user = null;
    } else {
      user = userFromClaims(found.claims);
    }
    // a legacy session keeps the end it had (its exp, in seconds): swapped, never extended
    const left = found.legacy && typeof found.claims.exp === 'number' ? found.claims.exp * 1000 - now() : null;
    if (!user || (left !== null && left <= 0)) return done({ user: null, claims: found.claims, dead: true });
    user = { ...user, is_admin: await adminOf(user) };
    const r = done({ user, claims: found.claims, legacy: found.legacy });
    if (found.legacy && res && !res.headersSent) {
      set(res, user, left !== null ? { ttl: Math.min(ttlFor(user), left) } : undefined);
      clearLegacy(res, found.legacy);
      r.upgraded = true;
    }
    return r;
  }

  /** The account without a database read: for a socket upgrade in an app with no `load`. An
   *  async isAdmin hook cannot answer here, so is_admin is false then: use resolve for that. */
  function peek(req) {
    const found = read(req);
    if (!found) return null;
    const user = load ? null : userFromClaims(found.claims);
    return user ? { ...user, is_admin: adminOfNow(user) } : null;
  }

  /** Sets req.user (null when signed out) and goes on; 500 when the row could not be read. */
  async function loadUser(req, res, next) {
    const r = await resolve(req, res);
    if (r.failed) return res.status(500).json({ error: 'Could not check your session. Try again.' });
    next();
  }

  /** loadUser, then 401 for no session. */
  async function requireUser(req, res, next) {
    const r = await resolve(req, res);
    if (r.failed) return res.status(500).json({ error: 'Could not check your session. Try again.' });
    if (!r.user) return res.status(401).json({ error: 'Not signed in' });
    next();
  }

  /** Renews a live session minted more than renewAfterMs ago. Returns whether it did. */
  async function renew(req, res) {
    const r = await resolve(req, res);
    if (!slide || !r.user || r.upgraded || typeof r.claims?.iat !== 'number') return false;
    if (now() - r.claims.iat * 1000 < renewAfterMs) return false;
    set(res, r.user);
    if (onRenew) {
      try {
        await onRenew(r.user, req);
      } catch (err) {
        console.error('Session renewal hook failed:', err?.message ?? err);
      }
    }
    return true;
  }

  /** Ends the session: `onSignOut(claims)` first (add one to the row's token_version, which
   *  refuses this cookie, any copy of it and every other device's), then the cookie. If
   *  onSignOut throws, the cookie stays and the caller says so: a sign-out that failed leaves
   *  the page signed in and able to try again. */
  async function signOut(req, res) {
    const found = read(req);
    if (found && onSignOut) await onSignOut(found.claims, req);
    clear(res);
  }

  return { name, cookieOpts, mint, set, clear, read, peek, resolve, loadUser, requireUser, renew, signOut, userFromClaims, isAdmin: adminOf, isAdminNow: adminOfNow };
}
