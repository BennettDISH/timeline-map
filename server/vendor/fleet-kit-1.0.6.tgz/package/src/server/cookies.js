// Cookies the kit sets, and reading them without cookie-parser.
//
// Every name starts with __Host-: the browser keeps such a cookie to this exact host, https
// only, path /, and refuses one of the same name from anywhere else. Behind a shared front
// door every app is a sibling under one domain, and a plain name could be planted by any of
// them with Domain=<that domain>: a session, or a sign-in state, of someone else's choosing.

/** `__Host-<app>_<what>`: session, oauth_state, oauth_next. */
export const hostCookie = (app, what) => `__Host-${app}_${what}`;

/** One set of options for setting and for clearing alike: a __Host- cookie set or cleared
 *  without Secure and path / is ignored by the browser, so a sign-out would leave the session
 *  in place. Always Secure: Chrome and Firefox keep a Secure cookie on http://localhost too
 *  (Safari does not). Pass maxAge only when setting; Express 4 lets a maxAge outlive a clear. */
export function cookieOpts(extra = {}) {
  return { httpOnly: true, secure: true, sameSite: 'lax', path: '/', ...extra };
}

/** The Cookie header as { name: value }. A malformed escape keeps its raw value instead of
 *  throwing: a bad cookie must never take a request down. */
export function parseCookies(header) {
  const out = {};
  String(header || '').split(';').forEach((part) => {
    const i = part.indexOf('=');
    if (i <= 0) return;
    const key = part.slice(0, i).trim();
    const raw = part.slice(i + 1).trim();
    if (key in out) return; // the first one wins, as in cookie-parser
    try {
      out[key] = decodeURIComponent(raw);
    } catch {
      out[key] = raw;
    }
  });
  return out;
}

/** One cookie of a request: req.cookies when cookie-parser ran, else the header itself (a
 *  WebSocket upgrade never passes through Express). */
export function readCookie(req, name) {
  if (req?.cookies && name in req.cookies) return req.cookies[name];
  return parseCookies(req?.headers?.cookie)[name];
}
