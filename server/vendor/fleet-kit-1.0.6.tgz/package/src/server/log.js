// One line per request with an id to find it again, and nothing secret: no query strings
// (Waypoint's ?code=&state= land on the callback URL), no bodies, headers or cookies, and
// path segments that look like tokens (invite and share links) logged as :token.
//
// A segment of 16 or more URL-safe characters is taken for a token. Shorter ones an app hands
// out (a 12-character share link, say) it names itself: requestLog({ tokens: ['/p/:token',
// '/api/shared/:token'] }), and every segment at a ':' place of a matching route is hidden.
import crypto from 'node:crypto';

const ID_RE = /^[A-Za-z0-9._-]{8,64}$/;
const LONG = /^[A-Za-z0-9_-]{16,}$/;

/** The route patterns as segment lists ('/p/:token' → ['', 'p', ':token']). */
const compile = (tokens = []) => tokens.map((t) => String(t).split('/'));

/** A path with its secret segments hidden: those at a ':' place of a matching route pattern
 *  (`tokens`, as compiled or as strings), and any of 16 or more URL-safe characters. */
export function scrubPath(p, tokens = []) {
  const segs = String(p).split('/');
  for (const pattern of typeof tokens[0] === 'string' ? compile(tokens) : tokens) {
    if (pattern.length > segs.length) continue;
    if (!pattern.every((part, i) => part.startsWith(':') || part === segs[i])) continue;
    pattern.forEach((part, i) => {
      if (part.startsWith(':')) segs[i] = part;
    });
  }
  return segs.map((s) => (LONG.test(s) ? ':token' : s)).join('/');
}

/** The request's path for a log line: originalUrl (req.path loses the mount under
 *  app.use('/api', ...)), cut at the query, tokens scrubbed. requestLog keeps it on the request
 *  (req.loggedPath) with the app's own token routes, so an error line hides the same. */
export const loggedPath = (req, tokens) => req?.loggedPath ?? scrubPath(String(req?.originalUrl ?? req?.url ?? '').split('?')[0], tokens);

export function requestLog({
  skip = (req) => req.path === '/health' || req.path === '/healthz',
  // looked up per line, so a test (or anything else) that swaps console.log sees the line
  log = (...a) => console.log(...a),
  tokens = [],
} = {}) {
  const patterns = compile(tokens);
  return (req, res, next) => {
    const given = req.get('x-request-id');
    req.id = given && ID_RE.test(given) ? given : crypto.randomUUID();
    res.set('X-Request-Id', req.id);
    req.loggedPath = scrubPath(String(req.originalUrl ?? req.url ?? '').split('?')[0], patterns);
    if (skip(req)) return next();
    const logged = req.loggedPath;
    const started = process.hrtime.bigint();
    res.on('finish', () => {
      const ms = Number(process.hrtime.bigint() - started) / 1e6;
      log(`${req.id} ${req.method} ${logged} ${res.statusCode} ${Math.round(ms)}ms`);
    });
    next();
  };
}

/** An error's log line: the request's id, method and scrubbed path, then the error. Never the
 *  body, query, headers, cookies, tokens or Waypoint's answers. */
export function logError(req, err, log = (...a) => console.error(...a)) {
  log(req?.id, req?.method, req ? loggedPath(req) : '', err);
}
