// The site admin: Waypoint central user ids in ADMIN_CENTRAL_USER_IDS, never an email (an email
// is a label Waypoint lets an account change; the id is the account). The list is read on every
// check, so a Railway variable change takes hold on the next request, and it fails closed: an
// empty list means nobody. A guest is never an admin, whatever id it carries.
//
// The /admin page is decided on the server before any of it goes out: signed out goes to sign in
// and comes back; anyone else signed in gets a plain 403 page with nothing of the admin area in
// it. The admin's data lives under /api/admin, which asks again (requireAdmin).

/** The listed ids, as numbers. */
export function adminIds(env = process.env) {
  return new Set(
    String(env.ADMIN_CENTRAL_USER_IDS || '')
      .split(',')
      .map((s) => s.trim())
      .filter(Boolean)
      .map(Number)
      .filter((n) => Number.isInteger(n) && n > 0)
  );
}

/** Whether a central id is on the list (a JSON number or a digit string). */
export function isAdminId(centralUserId, env = process.env) {
  if (centralUserId === null || centralUserId === undefined || centralUserId === '') return false;
  const n = Number(centralUserId);
  return Number.isInteger(n) && adminIds(env).has(n);
}

/** Whether an account ({ central_user_id, is_guest }) is the site admin right now. */
export function isAdmin(user, env = process.env) {
  return Boolean(user) && !user.is_guest && isAdminId(user.central_user_id, env);
}

const escapeHtml = (s) => String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);

export const ADMIN_ONLY_MESSAGE = 'This page is for the site admin.';

/** A small page of its own (no app styles, no script): a heading and a line of links. */
export function plainPage({ title, heading, links = [] }) {
  const line = links.map(([href, text]) => `<a href="${escapeHtml(href)}">${escapeHtml(text)}</a>`).join(' · ');
  return `<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>${escapeHtml(title)}</title><meta name="robots" content="noindex"></head>
<body style="font:16px/1.5 system-ui,sans-serif;max-width:32rem;margin:4rem auto;padding:0 1rem">
<h1 style="font-size:1.4rem">${escapeHtml(heading)}</h1>
<p>${line}</p>
</body></html>
`;
}

/** The 403 page: what it is, the way home, and a way to sign in as someone else. */
export function adminOnlyPage({ appName = 'the site', homeHref = '/', switchHref } = {}) {
  return plainPage({
    title: `Admin · ${appName}`,
    heading: ADMIN_ONLY_MESSAGE,
    links: [[homeHref, `Back to ${appName}`], ...(switchHref ? [[switchHref, 'Sign in as someone else']] : [])],
  });
}

/** /api/admin's gate, after the session middleware: 401 signed out, 403 anyone but the admin. */
export function requireAdmin(req, res, next) {
  if (!req.user) return res.status(401).json({ error: 'Not signed in' });
  if (!req.user.is_admin) return res.status(403).json({ error: 'Admin access required' });
  next();
}

/**
 * The gate in front of the admin's pages. `session` is the kit's session (createSession or a
 * waypoint's .session); `pages` limits it to the admin's real addresses (a RegExp on req.path,
 * so an old /admin/<page> that the app redirects elsewhere is left alone). The admin passes on
 * to the app, which serves its page.
 */
export function adminPage({ session, pages, appName, homeHref = '/', signInPath = '/api/auth/sso/login' } = {}) {
  if (!session?.resolve) throw new Error('adminPage needs the kit session');
  const page = adminOnlyPage({ appName, homeHref, switchHref: `${signInPath}?prompt=login&next=${encodeURIComponent('/admin')}` });
  return async (req, res, next) => {
    if (req.method !== 'GET' && req.method !== 'HEAD') return next();
    if (pages && !pages.test(req.path)) return next();
    res.set('Cache-Control', 'no-store');
    const found = await session.resolve(req, res);
    if (found.failed) return res.status(500).type('text/plain').send('Could not check your session. Try again.');
    if (!found.user) return res.redirect(`${signInPath}?next=${encodeURIComponent(req.originalUrl.split('?')[0])}`);
    if (!found.user.is_admin) return res.status(403).type('html').send(page);
    next();
  };
}
