// Rate limits, in memory (a deploy starts every window over, which is fine for these apps).
//
// Every app reaches Waypoint from its one server address, and Waypoint caps per calling
// address: without a limit here, one visitor posting junk sign-ins used up the cap and locked
// every player out. So every route that calls Waypoint is limited per visitor, and so are
// break-glass passwords and public writes.
//
// The visitor is req.ip with `trust proxy` set to 1: the last X-Forwarded-For entry, the one the
// platform's edge adds and a client cannot write. `true` would make req.ip the first entry, which
// the client writes itself. An IPv6 visitor usually holds a whole /64, so IPv6 counts by that.
import { isIPv6 } from 'node:net';

/**
 * The key to limit a visitor by. One IPv6 visitor usually holds a whole /64 (billions of
 * addresses), so IPv6 is counted by that prefix. IPv4, IPv4-mapped IPv6 (as plain IPv4) and the
 * rest of ::/80 (loopback) keep the full address.
 */
export function ipKey(ip) {
  const address = String(ip ?? 'unknown').split('%')[0].toLowerCase();
  if (!isIPv6(address)) return address;
  // Expand to eight 16-bit words; a dotted IPv4 tail is the last two.
  const words = (part) => (part ? part.split(':') : []).flatMap((g) => {
    if (!g.includes('.')) return [parseInt(g, 16)];
    const [a, b, c, d] = g.split('.').map(Number);
    return [a * 256 + b, c * 256 + d];
  });
  const [head, tail] = address.split('::');
  const left = words(head);
  const right = words(tail);
  const all = tail === undefined ? left : [...left, ...Array(8 - left.length - right.length).fill(0), ...right];
  if (all.slice(0, 5).some((w) => w !== 0)) {
    return `${all.slice(0, 4).map((w) => w.toString(16)).join(':')}::/64`;
  }
  if (all[5] === 0xffff) return [all[6] >> 8, all[6] & 255, all[7] >> 8, all[7] & 255].join('.');
  return address;
}

/** The visitor's key for a request. */
export const clientKey = (req) => ipKey(req.ip ?? req.socket?.remoteAddress ?? 'unknown');

/**
 * A sliding window per key: `hit(key)` counts one and answers { ok, retryAfter, undo }, where
 * retryAfter is the seconds until a slot frees and undo() gives the slot back (a guest that was
 * never minted, say). Past `maxKeys` stored keys it forgets visitors whose window has passed,
 * then the ones seen least recently, so a flood of new keys can't reset everyone's limits.
 */
export function limiter({ windowMs, max, maxKeys = 10000, now = Date.now }) {
  if (!(windowMs > 0) || !(max > 0)) throw new Error('limiter needs windowMs and max');
  const hits = new Map(); // key -> times, oldest first
  const recent = (key, at) => (hits.get(key) || []).filter((t) => at - t < windowMs);
  function hit(key) {
    const at = now();
    const times = recent(key, at);
    const ok = times.length < max;
    if (ok) times.push(at);
    // re-inserted so the Map runs from least to most recently seen
    hits.delete(key);
    hits.set(key, times);
    if (hits.size > maxKeys) {
      for (const [k, t] of hits) if (!t.length || at - t[t.length - 1] >= windowMs) hits.delete(k);
      for (const k of hits.keys()) {
        if (hits.size <= maxKeys) break;
        hits.delete(k);
      }
    }
    const retryAfter = ok ? 0 : Math.max(1, Math.ceil((times[times.length - max] + windowMs - at) / 1000));
    return {
      ok,
      retryAfter,
      undo() {
        if (!ok) return;
        const list = hits.get(key);
        const i = list ? list.lastIndexOf(at) : -1;
        if (i >= 0) list.splice(i, 1);
      },
    };
  }
  return { hit, size: () => hits.size };
}

/**
 * Middleware: at most `max` requests per `windowMs` per key, then 429 JSON { error: message }
 * with Retry-After. `key(req)` defaults to the visitor's address (pass the account to count a
 * table of players on one network apart). `onLimit(req, res)` answers instead when the caller is
 * a browser page rather than the app's own fetch (Retry-After is already set).
 */
export function rateLimit({ windowMs, max, message = 'Too many requests. Wait a few minutes and try again.', key = clientKey, onLimit, maxKeys } = {}) {
  const counts = limiter({ windowMs, max, maxKeys });
  const middleware = (req, res, next) => {
    const r = counts.hit(key(req));
    if (r.ok) return next();
    res.set('Retry-After', String(r.retryAfter));
    return onLimit ? onLimit(req, res) : res.status(429).json({ error: message });
  };
  middleware.limiter = counts;
  return middleware;
}

/** An amount per key for a fixed window: `room(key)` is what is left, `add(key, n)` spends n (a
 *  negative n gives it back), `resetIn(key)` is the seconds to the window's end. Daily upload
 *  bytes per account, say. */
export function budget(windowMs, max, { now = Date.now } = {}) {
  const spent = new Map(); // key -> { used, until }
  const live = (key, at) => {
    const h = spent.get(key);
    return h && h.until > at ? h : null;
  };
  return {
    max,
    room: (key) => max - (live(key, now())?.used ?? 0),
    add(key, n) {
      const at = now();
      const h = live(key, at) ?? { used: 0, until: at + windowMs };
      h.used = Math.max(0, h.used + n);
      spent.set(key, h);
      if (spent.size > 10000) for (const [k, v] of spent) if (v.until <= at) spent.delete(k);
    },
    resetIn(key) {
      const h = live(key, now());
      return h ? Math.ceil((h.until - now()) / 1000) : 0;
    },
  };
}

/** Trust the one proxy in front (the platform's edge) and only it. Call right after
 *  express(): req.protocol is then the browser's https, and req.ip the address limits count. */
export function trustOneProxy(app) {
  app.set('trust proxy', 1);
  return app;
}

/** Throws unless `trust proxy` is exactly 1: an app that trusts more counts a client-written
 *  address in every limit. For boot, after the app is set up. */
export function assertTrustProxy(app) {
  const setting = app.get('trust proxy');
  if (setting !== 1) throw new Error(`trust proxy must be 1 (one hop: the platform's edge), not ${JSON.stringify(setting)}`);
}
