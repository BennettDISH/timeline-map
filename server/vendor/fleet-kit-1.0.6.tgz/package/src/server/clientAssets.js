// The kit's browser files for an app with no bundler (plain static pages): mount
//   app.use('/fleet-kit', clientAssets());
// and the page loads /fleet-kit/topbar.js (a module) and /fleet-kit/topbar.css. Revalidated on
// every load, so a kit bump shows up on the next visit. An app with a bundler imports
// 'fleet-kit/client/topbar' instead.
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const FILES = { 'topbar.js': 'text/javascript; charset=utf-8', 'topbar.css': 'text/css; charset=utf-8' };

/** Where src/client is: next to this file in the package, or (from the CommonJS build in
 *  dist/cjs/server) three levels up. */
export function clientDir() {
  // eslint-disable-next-line no-undef
  const here = typeof __dirname === 'string' ? __dirname : path.dirname(fileURLToPath(import.meta.url));
  const found = [path.join(here, '..', 'client'), path.join(here, '..', '..', '..', 'src', 'client')].find((d) => fs.existsSync(path.join(d, 'topbar.js')));
  if (!found) throw new Error('fleet-kit: client files not found');
  return found;
}

export function clientAssets() {
  const dir = clientDir();
  return (req, res, next) => {
    if (req.method !== 'GET' && req.method !== 'HEAD') return next();
    const name = req.path.replace(/^\//, '');
    if (!Object.hasOwn(FILES, name)) return next();
    res.set({ 'Content-Type': FILES[name], 'Cache-Control': 'no-cache' });
    res.sendFile(path.join(dir, name), { headers: { 'Cache-Control': 'no-cache' } });
  };
}
